package com.practice.list.music.run;

import com.practice.list.music.view.MusicView;


public class Run {

	public static void main(String[] args) {
		MusicView run = new MusicView();
		
		run.mainMenu();
	}

}
